package com.example.apptintuc;

import android.view.View;

/**
 * Created by reale on 10/4/2017.
 */

public interface ItemClickListener {
        void onClick(View view, int position, boolean isLongClick);
}
